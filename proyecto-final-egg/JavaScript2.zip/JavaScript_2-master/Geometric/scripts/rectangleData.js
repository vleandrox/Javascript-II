export const rectangles = [
    { altura: 10, ancho: 20 },
    { altura: 30, ancho: 40 },
    { altura: 50, ancho: 60 }

];