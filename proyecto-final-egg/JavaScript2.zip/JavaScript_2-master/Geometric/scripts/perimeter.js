function perimetro(rectangulo){
    return 2*(rectangulo.altura + rectangulo.ancho);
}

export {perimetro};