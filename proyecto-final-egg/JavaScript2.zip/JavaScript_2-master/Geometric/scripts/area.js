function area(rectangulo){
    return rectangulo.altura * rectangulo.ancho;
}

export {area};