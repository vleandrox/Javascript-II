export interface Data {
    firstName: string;
    lastName: string;
    age: number;
    email: string;
    isEmployed: boolean;
}